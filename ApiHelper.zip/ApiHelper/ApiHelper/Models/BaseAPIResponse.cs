﻿using System;
using System.Net;

namespace ApiHelper.Models
{
    public class BaseAPIResponse : IAPIResponse
    {
        public Exception ErrorException { get; set; }
        public string ErrorMessage { get; set; }
        public HttpStatusCode StatusCode { get; set; }
    }
}
