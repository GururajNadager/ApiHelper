﻿using System;
using System.Net;

namespace ApiHelper.Models
{
    public interface IAPIResponse
    {
        Exception ErrorException { get; set; }
        string ErrorMessage { get; set; }
        HttpStatusCode StatusCode { get; set; }
    }
}