﻿using ApiHelper.Models;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Net.NetworkInformation;

namespace ApiHelper
{
    /// <summary>
    /// Class contains Helper methods for making API calls
    /// </summary>
    public class RestHelper
    {
        #region Private Constructors

        /// <summary>
        /// Prevents a default instance of the <see cref="RestHelper"/> class from being created
        /// </summary>
        private RestHelper()
        {
        }

        #endregion Private Constructors

        #region Public Properties

        public static string BaseUrl { get; set; }

        public static string CacheControl { get; set; }

        public static string ContentType { get; set; }

        /// <summary>
        /// Gets a value indicating whether Network Avaliability is present
        /// </summary>
        public static bool IsOnline
        {
            get { return NetworkInterface.GetIsNetworkAvailable(); }
        }

        public static string Locale { get; set; }

        public static string Version { get; set; }

        #endregion Public Properties

        #region Public Methods

        /// <summary>
        /// Converts string to Type
        /// </summary>
        /// <typeparam name="T">Target deserialization type</typeparam>
        /// <param name="arg">data to be converted as Type (T)</param>
        /// <returns>Type (T)</returns>
        public static T ConvertJsonToObject<T>(string arg)
        {
            return JsonConvert.DeserializeObject<T>(arg);
        }

        /// <summary>
        /// Converts Type (T) to string
        /// </summary>
        /// <typeparam name="T">Source deserialization type</typeparam>
        /// <param name="arg">data to be converted as string</param>
        /// <returns>Serialized string </returns>
        public static string ConvertObjectToJson<T>(T arg)
        {
            return JsonConvert.SerializeObject(arg);
        }

        /// <summary>
        /// Performs HTTP GET Request
        /// </summary>
        /// <typeparam name="V">Response Object Type</typeparam>
        /// <param name="methodName">unique name used for logging</param>
        /// <param name="url">Resource URL</param>
        /// <param name="requestBody">parameters to be passed to the request</param>
        /// <returns></returns>
        public static V Get<V>(string methodName, string url, object requestBody) where V : IAPIResponse, new()
        {
            return Execute<V>(methodName, url, Method.GET, ConvertObjectToJson(requestBody));
        }


        private static V Execute<V>(string methodName, string url, Method method, string requestBody) where V : IAPIResponse, new()
        {
            var requestDateTime = DateTime.Now;
            var client = new RestClient(BaseUrl);
            var request = new RestRequest(url.Trim(), method);
            AddHeaderParameter(request);
            request.AddParameter(ContentType, requestBody, ParameterType.RequestBody);
            var response = client.Execute(request);

            // operation timeout when system is offline
            if (response.ErrorException != null)
            {
            }

            return MapResponse<V>(methodName, response, url, requestDateTime, requestBody);
        }

        /// <summary>
        /// Performs HTTP POST Request
        /// </summary>
        /// <typeparam name="K">Input request Type</typeparam>
        /// <typeparam name="V">Output Response Type</typeparam>
        /// <param name="methodName">unique name used for logging</param>
        /// <param name="url">Resource URL</param>
        /// <param name="requestBody">parameters to be passed to the request</param>
        /// <returns></returns>
        public static V Post<K, V>(string methodName, string url, K requestBody) where K : class
                                                                              where V : IAPIResponse, new()
        {
            return Execute<V>(methodName, url, Method.POST, ConvertObjectToJson(requestBody));
        }

        #endregion Public Methods

        #region Private Methods

        private static void AddHeaderParameter(RestRequest restRequest)
        {
            restRequest.AddHeader("cache-control", CacheControl);
            restRequest.AddHeader("locale", Locale);
            restRequest.AddHeader("version", Version);
            restRequest.AddHeader("content-type", ContentType);
        }

        private static V MapResponse<V>(string methodName, IRestResponse response, string url, DateTime requestDateTime,
                                                   string requestBody) where V : IAPIResponse, new()
        {
            V responseObject = default(V);

            if (response != null)
            {
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    responseObject = JsonConvert.DeserializeObject<V>(response.Content);
                }

                responseObject = responseObject != null ? responseObject : Activator.CreateInstance<V>();
                responseObject.ErrorException = response.ErrorException;
                responseObject.ErrorMessage = response.ErrorMessage;
                responseObject.StatusCode = response.StatusCode;
            }

            return responseObject;
        }

        #endregion Private Methods
    }
}